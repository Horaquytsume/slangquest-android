# SlangQuest Android — build 0.1.0

An offline-first Android wrapper for the SlangQuest English-learning prototype. Lessons, quiz, XP, streak and saved expressions are stored locally in WebView localStorage; no account, analytics, ads, network permission, microphone or remote AI service is included.

## Build
The GitHub Actions workflow builds a debug APK using Android SDK 36 and Java 17. Debug APKs are for testing and sideloading, not public Play Store release. A production release requires a signed Android App Bundle (AAB), store listing, privacy policy and Play Console review.
